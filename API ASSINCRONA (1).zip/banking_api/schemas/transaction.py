from pydantic import BaseModel, Field, field_validator
from datetime import datetime
from typing import Optional, List
from models.transaction import TransactionType


class TransactionCreate(BaseModel):
    type: TransactionType = Field(..., examples=["deposito"])
    amount: float = Field(..., gt=0, examples=[500.00])
    description: Optional[str] = Field(None, max_length=255, examples=["Depósito inicial"])

    @field_validator("amount")
    @classmethod
    def amount_must_be_positive(cls, v):
        if v <= 0:
            raise ValueError("O valor da transação deve ser positivo")
        return round(v, 2)


class TransactionResponse(BaseModel):
    id: int
    type: TransactionType
    amount: float
    description: Optional[str]
    balance_after: float
    created_at: datetime

    model_config = {"from_attributes": True}


class StatementResponse(BaseModel):
    user_id: int
    user_name: str
    current_balance: float
    total_transactions: int
    transactions: List[TransactionResponse]

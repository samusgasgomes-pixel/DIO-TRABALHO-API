from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from typing import Optional
from database import get_db
from models.user import User
from models.transaction import Transaction, TransactionType
from schemas.transaction import TransactionCreate, TransactionResponse, StatementResponse
from services.auth import get_current_user

router = APIRouter(prefix="/transactions", tags=["Transações"])

WITHDRAWAL_TYPES = {TransactionType.WITHDRAWAL, TransactionType.TRANSFER, TransactionType.PAYMENT}


@router.post(
    "/",
    response_model=TransactionResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Registrar transação",
    description="Cria uma nova transação (depósito, saque, transferência ou pagamento) para o usuário autenticado.",
)
async def create_transaction(
    data: TransactionCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    # Reload user inside this session to get fresh balance
    result = await db.execute(select(User).where(User.id == current_user.id))
    user = result.scalar_one()

    if data.type in WITHDRAWAL_TYPES:
        if user.balance < data.amount:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"Saldo insuficiente. Saldo atual: R$ {user.balance:.2f}",
            )
        user.balance = round(user.balance - data.amount, 2)
    else:
        user.balance = round(user.balance + data.amount, 2)

    transaction = Transaction(
        user_id=user.id,
        type=data.type,
        amount=data.amount,
        description=data.description,
        balance_after=user.balance,
    )
    db.add(transaction)
    await db.commit()
    await db.refresh(transaction)
    return transaction


@router.get(
    "/statement",
    response_model=StatementResponse,
    summary="Extrato bancário",
    description="Retorna o extrato completo com todas as transações do usuário autenticado.",
)
async def get_statement(
    skip: int = Query(0, ge=0, description="Registros para pular (paginação)"),
    limit: int = Query(20, ge=1, le=100, description="Máximo de registros (padrão: 20)"),
    type: Optional[TransactionType] = Query(None, description="Filtrar por tipo"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    # Reload user in this session
    result = await db.execute(select(User).where(User.id == current_user.id))
    user = result.scalar_one()

    query = select(Transaction).where(Transaction.user_id == user.id)
    count_query = select(func.count()).where(Transaction.user_id == user.id)

    if type:
        query = query.where(Transaction.type == type)
        count_query = count_query.select_from(Transaction).where(
            Transaction.user_id == user.id, Transaction.type == type
        )

    query = query.order_by(Transaction.created_at.desc()).offset(skip).limit(limit)

    tx_result = await db.execute(query)
    count_result = await db.execute(count_query)

    transactions = tx_result.scalars().all()
    total = count_result.scalar()

    return StatementResponse(
        user_id=user.id,
        user_name=user.name,
        current_balance=user.balance,
        total_transactions=total,
        transactions=transactions,
    )


@router.get(
    "/{transaction_id}",
    response_model=TransactionResponse,
    summary="Detalhe de transação",
    description="Retorna os dados de uma transação específica do usuário.",
)
async def get_transaction(
    transaction_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(Transaction).where(
            Transaction.id == transaction_id,
            Transaction.user_id == current_user.id,
        )
    )
    transaction = result.scalar_one_or_none()
    if not transaction:
        raise HTTPException(status_code=404, detail="Transação não encontrada")
    return transaction

import os

SECRET_KEY = os.getenv("SECRET_KEY", "super-secret-banking-key-change-in-production-2024")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from database import init_db
from routers import auth, transactions


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    yield


app = FastAPI(
    title="🏦 API Bancária Assíncrona",
    description="""
## API Bancária desenvolvida com FastAPI + SQLAlchemy Async

### Funcionalidades

- **Autenticação JWT** — Cadastro e login com tokens seguros (JWS/HS256)
- **Transações** — Depósito, saque, transferência e pagamento
- **Extrato** — Histórico paginado com filtro por tipo
- **Validações** — Saldo insuficiente, campos obrigatórios, valores positivos

### Como usar

1. Crie sua conta em `/auth/register`
2. Faça login em `/auth/login` e copie o `access_token`
3. Clique em **Authorize** 🔒 e cole o token
4. Use os endpoints de transações e extrato

### Tipos de Transação

| Tipo | Operação |
|------|----------|
| `deposito` | Crédito na conta |
| `saque` | Débito na conta |
| `transferencia` | Débito na conta |
| `pagamento` | Débito na conta |
    """,
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(transactions.router)


@app.get("/", tags=["Root"], summary="Healthcheck")
async def root():
    return {
        "status": "online",
        "app": "API Bancária Assíncrona",
        "version": "1.0.0",
        "docs": "/docs",
    }
